<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Estimate extends Model
{
    //
    public function purchaseRequest()
    {
        return $this->belongsTo('App\PurchaseRequest');
    }

    public function company()
    {
        return $this->belongsTo('App\Company');
    }
}
