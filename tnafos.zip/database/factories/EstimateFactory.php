<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Estimate;
use Faker\Generator as Faker;

$factory->define(Estimate::class, function (Faker $faker) {
    return [
        //
    ];
});
