<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Line;
use Faker\Generator as Faker;

$factory->define(Line::class, function (Faker $faker) {
    return [
        //
    ];
});
