<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PurchaseRequest;
use Faker\Generator as Faker;

$factory->define(PurchaseRequest::class, function (Faker $faker) {
    return [
        //
    ];
});
