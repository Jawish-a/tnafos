<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Settings;
use Faker\Generator as Faker;

$factory->define(Settings::class, function (Faker $faker) {
    return [
        //
    ];
});
