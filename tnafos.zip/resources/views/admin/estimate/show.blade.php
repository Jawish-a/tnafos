@extends('layouts.admin.master')
@section('pagecss')
<link href="{{asset('vendor/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
@endsection
@section('page_title')
List of Purchase Requests
<a href="{{route('service.create')}}" class="float-right fa fa-plus btn-circle btn-tnafos shadow"></a>
@endsection
@section('content')
<div class="row">
    <div class="col-12">
        <div class="card m-b-20">
            <div class="card-body">

                <div class="row">
                    <div class="col-12">
                        <div class="invoice-title">
                            <h4 class="float-right font-16"><strong>Purchase Request #
                                    {{$purchaseRequest->uuid}}</strong></h4>
                            <h3 class="mt-0">
                                <img src="{{asset('/img/companies')}}/{{$purchaseRequest->company->logo}}" alt="logo"
                                    height="48">
                            </h3>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-6">
                                <address>
                                    <strong>From:</strong><br>
                                    {{$purchaseRequest->company->name}}<br>
                                    1234 Main<br>
                                    Apt. 4B<br>
                                    Springfield, ST 54321
                                </address>
                            </div>
                            <div class="col-6 text-right">
                                <address>
                                    <strong>To:</strong><br>
                                    {{auth()->user()->company->name}}<br>
                                    1234 Main<br>
                                    Apt. 4B<br>
                                    Springfield, ST 54321
                                </address>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 m-t-30">
                                <address>
                                    <strong>Contact Details:</strong><br>
                                    Visa ending **** 4242<br>
                                    {{$purchaseRequest->company->email}}
                                </address>
                            </div>
                            <div class="col-6 m-t-30 text-right">
                                <address>
                                    <strong>Order Date:</strong><br>
                                    {{$purchaseRequest->date}}<br><br>
                                </address>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div>
                            <div class="p-2">
                                <h3 class="font-16"><strong>Purchase Request summary</strong></h3>
                            </div>
                            <div class="">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <td><strong>Item</strong></td>
                                                <td class="text-center"><strong>Service Name</strong></td>
                                                <td class="text-right"><strong>Service Details</strong></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- foreach ($order->lineItems as $line) or some such thing here -->
                                            @foreach ($purchaseRequest->lines as $line)
                                            <tr>
                                                <td>{{$purchaseRequest->uuid}} - 1</td>
                                                <td class="text-center">{{$line->service->name}}</td>
                                                <td class="text-right">{{$line->service->description}}</td>
                                            </tr>
                                            @endforeach
                                            <tr>
                                                <td class="no-line"></td>
                                                <td class="no-line text-center">
                                                    <strong>Details</strong></td>
                                                <td class="no-line text-right">
                                                    <h4 class="m-0">{{$purchaseRequest->details}}</h4>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="d-print-none">
                                    <div class="float-right">
                                        <a href="javascript:window.print()" class="btn btn-success "><i
                                                class="fa fa-print"></i></a>
                                        <a href="#" class="btn btn-primary ">Create Estimate</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div> <!-- end row -->

            </div>
        </div>
    </div> <!-- end col -->
</div>
@endsection
@section('page_scripts')

@endsection
