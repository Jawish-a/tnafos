<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @include('layouts.admin.partials.head')
</head>
<body id="page-top">
    @include('layouts.admin.partials.body')
</body>
</html>
