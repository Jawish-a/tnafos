<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @include('layouts.home.partials.head')
</head>
<body id="page-top">
    @include('layouts.home.partials.body')
</body>
</html>
