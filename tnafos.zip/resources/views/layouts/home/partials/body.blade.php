
{{-- javascripts and other scripts --}}
@include('layouts.home.partials.script')
