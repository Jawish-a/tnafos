<!DOCTYPE html>
<html lang="en">

<head>
    @include('layouts.search.partials.head')
</head>

<body>
    @include('layouts.search.partials.body')
    @include('layouts.search.partials.scripts')
</body>

</html>
