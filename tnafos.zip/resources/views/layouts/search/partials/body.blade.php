@include('layouts.search.partials.navbar')

@yield('content')
