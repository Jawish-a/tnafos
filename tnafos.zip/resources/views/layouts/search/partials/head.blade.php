<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Tnafos</title>
{{-- styles and css requirements --}}
<link rel="stylesheet" href="{{asset('vendor/bootstrap/css/bootstrap.min.css')}}">
<link href="https://fonts.googleapis.com/css?family=Tajawal&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{asset('vendor/fontawesome/css/all.css')}}">
<link rel="stylesheet" href="{{asset('css/admin.css')}}">

{{-- page specific style --}}
@yield('pagecss')
